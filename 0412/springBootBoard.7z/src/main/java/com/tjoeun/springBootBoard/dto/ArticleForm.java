package com.tjoeun.springBootBoard.dto;

import com.tjoeun.springBootBoard.entity.Article;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor // 모든 필드를 사용하는 생성자
@NoArgsConstructor // 기본 생성자 자동완성
// @RequiredArgsConstructor // 특정 필드(@NonNull 어노테이션이 붙은)를 사용하는 생성자 자동완성
// @Getter // getter 메소드 자동완성
// @Setter // setter 메소드 자동완성
// @ToString // toString 메소드 자동완성
// @EqualsAndHashCode // equals, hashcode 메소드 자동완성
// @Data 어노테이션은 getter, setter, toString, equalsandHashcode 메소드를 자동완성 시켜준다.
// @Data 어노테이션은 실무에서는 무겁과 객체의 안정성을 떨어뜨리므로 사용을 지양한다.
@Data
@Builder
public class ArticleForm { // 메인글 1건을 기억하는 클래스

//	@RequiredArgsConstructor 어노테이션을 사용하려면 생성자를 자동완성하려는 필드에 @NonNull
//	어노테이션을 붙여준다.
	private Long id;
//	@NonNull 어노테이션을 붙여준 필드는 null 값을 허용하지 않는다.
//	@NonNull
	private String title; 
	private String content;
	
	
//	DTO 클래스의 데이터를 엔티티 클래스 객체로 변환해서 리턴하는 메소드를 추가한다.
	public Article toEntity( ) {
//		return new Article(null, title, content);
//	추가된 id 필드도 엔티티를 초기화할 수 있도록 수정한다.
		return new Article(id, title, content);
	
	}
	                               
	

	
	
	
}
