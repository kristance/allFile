package com.tjoeun.springBootBoard.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// JPA(Java Persistence API)를 사용해서 테이블을 작성하는 클래스는 @Entity 어노테이션을 붙여서
// 선언해야 하고 엔티티라 부른다.
//	@Entity 어노테이션을 붙여 선언한 클래스 이름으로 springBoot가 자동으로 테이블을 만들고
// 클래스 내부에서 선언한 필드 이름으로 테이블을 구성하는 필드(컬럼, 속성)를 만들어준다.
@Entity // 현재 클래스는 엔티티로 사용된느 클래스임을 의미한다.
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Builder
public class Article { // 메인글
	
//	기본키로 사용할 필드 선언
//	엔티티 객체에서 기본키를 생성하려면 @Id와 @GeneratedValue 어노테이션을 함께 사용해야 한다.
	@Id // Id 어노테이션을 붙여 선언한 필드는 기본키로 사용된다.
//	@GeneratedValue // @GeneratedValue 어노테이션을 붙여 기본키 값을 자동으로 생성한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY) // 시퀀스를 자동으로 증가하게 한다.
	private Long id;
	
//	데이터를 저장할 필드 선언
	@Column // @Column 어노테이션을 붙여 선언한 필드는 데이터를 저장하는 필드로 사용된다.
	private String title;
	@Column // @Column 어노테이션을 붙여 선언한 필드는 데이터를 저장하는 필드로 사용된다.
	private String content;
	
	
//	넘어오지 않은 데이터는 기존 데이터를 유지하고 넘어온 데이터는 수정하는 메소드
	public void patch(Article article) {
		if (article.title != null) {
			this.title = article.title; // this.title은 patch 메소드를 실행한 객체를 지칭, article.title은 parameter로 넣은 객체를 지칭
		}
		if (article.content != null) {
			this.content = article.content;
		}
	}
	
	
	
	
}
