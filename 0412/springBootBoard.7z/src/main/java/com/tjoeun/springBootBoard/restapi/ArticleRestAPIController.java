package com.tjoeun.springBootBoard.restapi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tjoeun.springBootBoard.dto.ArticleForm;
import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.repository.ArticleRepository;
import com.tjoeun.springBootBoard.service.ArticleService;

import lombok.extern.slf4j.Slf4j;

//	@RestController 어노테이션은 RestAPI용 컨트롤러로 사용됨을 의미한다.
//	view페이지가 아닌 JSON 타입의 데이터를 리턴한다.
@RestController
@Slf4j
public class ArticleRestAPIController {
	
//	@Autowired
//	private ArticleRepository articleRepository;
//	ArticleRestAPIController에서 사용하던 ArticleRepository를 Service 계층으로 넘겨서 사용하고, 
//	ArticleRestAPIController에서는 ArticleService 객체를 통해  ArticleRepository를 사용한다.
	@Autowired //@Service 어노테이션을 붙여서 선언한 객체의 bean을 springBoot가 자동으로 초기화한다.
	private ArticleService articleService;
	
	
//	Article 테이블 전체 글 조회
	@GetMapping("/restapi/articles") // CRUD ->  Read, SQL -> select
	public List<Article> index() {
		log.info("ArticleRestAPIController -> index()");
		
		return articleService.index();
	}
	
//	Article 테이블 특정 글 조회
	@GetMapping("/restapi/articles/{id}")
	public Article show(@PathVariable Long id ) {
		log.info("ArticleRestAPIController -> show()");
		
		return articleService.show(id);
	}
	
	
//	Article 테이블에 글 1건 저장
	@PostMapping("/restapi/articles/") // CRUD -> Create, SQL -> Insert
//	form에서 데이터를 받아올 때는 커맨드 객체로 받으면 되지만 RestAPI에서 JSON으로 형태로 보내는 데이터를
//	받을 때는 BODY 부분에 담겨 넘어오는 데이터를 받아야 하므로 데이터를 받을 커맨드 객체 앞에
//	@RequestBody 어노테이션을 붙여서 받아야한다.
//	http 상태 코드를 리턴하려면 ResponseEntity 클래스 객체를 사용해야 한다.
//	ResponseEntity<Article>를 리턴 타입으로 사용하면 ResponseEntity 객체에 Article 객체를 담아서 리턴한다.
	public ResponseEntity<Article> create (@RequestBody ArticleForm articleForm ) {
		log.info("ArticleRestAPIController -> create()");
//		System.out.println("create -> articleform -> " + articleForm);
		
		Article saved = articleService.create(articleForm);
		
//		return saved;
//		정상적으로 저장했으면 정상 응답(HttpStatus.CREATED : 201)을 보내고, 
//		저장에 실패했으면 잘못된 요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
		return saved != null ? 
				ResponseEntity.status(HttpStatus.CREATED).body(saved) :
//				ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
//				body() 메소드는 body에 데이터를 담아서 넘기고, build() 메소드는 body 없이 넘긴다.
				ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
					
		
	}
	
//	Article 테이블의 글 1건 수정
	@PatchMapping("/restapi/articles/{id}") // CRUD -> Update, SQL -> update
	public ResponseEntity<Article> update (@PathVariable Long id, @RequestBody ArticleForm articleForm) {
		log.info("ArticleRestAPIController -> update()");
//		System.out.println("update -> #id -> " + id);
//		System.out.println("update -> #articleform -> " + articleForm);
		
		/*
//		수정할 데이터가 저장된 엔티티 객체를 생성한다.
		Article article = articleForm.toEntity();
//		수정할 엔티티를 조회한다.
		Article target = articleRepository.findById(id).orElse(null);
		System.out.println("update -> #id -> " + id + ", #target -> " + target);
//		잘못된 요청(수정할 id에 해당되는 글이 없거나, id가 articleForm에 들어있는 id가 다를 경우)를 처리한다.
		if (target == null || id != target.getId()) {
			System.out.println("잘못된 요청입니다. id -> " + id + ", target -> " + target);
//			잘못된 요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		} else {
			
//		수정 후 정상 응답(HttpStatus.OK : 200)을 보낸다.
//			if (article.getContent() != null) {
//				target.setContent(article.getContent());
//			} 
//			
//			if (article.getTitle() != null) {
//				target.setTitle(article.getTitle());
//			}
			
			target.patch(article);
			*/
			
			Article updated = articleService.update(id, articleForm);
			System.out.println("ArticleRestAPIController -> update() -> updated -> " + updated);
//			정상적으로 수정했으면 정상 응답(HttpStatus.OK : 200)을 보내고, 
//			수정에 실패했으면 잘못된 요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
			return updated != null ?
					ResponseEntity.status(HttpStatus.OK).body(updated) :
					ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
				
		
		
	}
	
	
//	Article 테이블의 글 1건 삭제
	@DeleteMapping("/restapi/articles/{id}")  //CRUD -> Delete, SQL -> Delete
	public ResponseEntity<Article> delete (@PathVariable Long id) {
		log.info("ArticleRestAPIController -> delete()");
		System.out.println("delete -> #id -> " + id);
		
		/*
//		삭제할 엔티티를 조회한다.
		Article target = articleRepository.findById(id).orElse(null);
//		잘못된 요청(삭제할 id에 해당되는 글이 없을 경우)를 처리한다.
		if (target == null) {
			System.out.println("잘못된 요청입니다. id -> " + id + ", target -> " + target);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		} 
		
		*/
		
//		정상적으로 삭제했으면 정상 응답(HttpStatus.NO_CONTENT : 204)을 보내고, 
//		삭제에 실패했으면 잘못된 요청 응답(HttpStatus.BAD_REQUEST: 400)을 보낸다.
		Article deleted = articleService.delete(id);
		return deleted != null ?
				ResponseEntity.status(HttpStatus.NO_CONTENT).body(deleted) :
				ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
				
		
	}
	
	
	@PostMapping("/restapi/transaction")
	public ResponseEntity<List<Article>> trasaction (@RequestBody List<ArticleForm> articleForms) {
		log.info("ArticleRestAPIController -> transaction()");
		System.out.println("trasaction -> #articleForms -> " + articleForms);
		List<Article> createList = articleService.createArticles(articleForms);
		
		return createList != null ? 
				ResponseEntity.status(HttpStatus.OK).body(createList):
				ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
					
	}
	
	
	
	
}
