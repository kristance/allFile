package com.tjoeun.springBootBoard.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.tjoeun.springBootBoard.dto.ArticleForm;
import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//	@Service 어노테이션을 붙여준 클래스는 springBoot가 자동으로 객체(bean)를 생성해 등록한다.
@Service
public class ArticleService {
	
	@Autowired
	private ArticleRepository articleRepository;
	
//	Article 테이블 전체 글 조회
	public List<Article> index() {
		log.info("ArticleService -> index()");
	
		return articleRepository.findAll();
	}
	
//	Article 테이블 특정 글 조회
	public Article show(@PathVariable Long id ) {
		log.info("ArticleService -> show()");
		
		return articleRepository.findById(id).orElse(null);
	}

	
//	Article 테이블에 글 1건 저장
	public Article create(ArticleForm articleForm) {
		log.info("ArticleService -> create()");
		System.out.println("create -> articleform -> " + articleForm);
//		save() 메소드로 insert sql 명령을 실행할 때 id는 데이터베이스가 자동으로 생성하므로,
//		id가 존재하는 데이터가 넘어온 경우 테이블에 저장하지 않는다.
		Article article = articleForm.toEntity();
		if (article.getId() != null) {
			log.info("id가 null이 아니면 insert sql 명령을 실행하면 안됨");
			return null;
		} 
		return articleRepository.save(article);
	}
	
	
//	Article 테이블의 글 1건 수정
	public Article update ( Long id, ArticleForm articleForm) {
		log.info("ArticleService -> update()");
		System.out.println("ArticleService- > update -> #id -> " + id);
		System.out.println("ArticleService- > update -> #articleform -> " + articleForm);
		
		Article article = articleForm.toEntity();
		
		Article target = articleRepository.findById(id).orElse(null);
		System.out.println("ArticleService- > update -> #target -> " + target);
		
		if (target == null || id != target.getId()) {
			System.out.println("ArticleService- > update -> Wrong Request!!!");
			return null;
			
		} 
		
//		id만 존재하면 null을 리턴하는 코드
		if (article.getTitle() == null && article.getContent() == null) {
			System.out.println("ArticleService- > update -> onlyID -> Wrong Request!!!");
			return null;
		}
		
			target.patch(article);
			
		return articleRepository.save(target);
		
	}
	
//	Article 테이블의 글 1건 삭제
	public Article delete (Long id) {
		log.info("ArticleService -> delete()");
		Article target = articleRepository.findById(id).orElse(null);
		
		if (target == null) {
			System.out.println("잘못된 요청입니다. id -> " + id + ", target -> " + target);
			return null;
		} 
		
		articleRepository.delete(target);
		return target;
		
	}

	
	
//	트랜젝션
//	@Transactional 어노테이션은 @Transactional 어노테이션을 지정한 메소드를 하나의 트랜젝션으로 묶는다.
//	@Transactional 어노테이션이 지정된 메소드가 정상적으로 실행되면 commit되고 정상적으로 실행되지만,
//	정상적으로 실행되지 않으면 rollback 된다.
	@Transactional
	public List<Article> createArticles(List<ArticleForm> articleForms) {
		log.info("ArticleService -> createArticles()");
		System.out.println("ArticleService -> #articleForms -> " + articleForms);
		
//		articleForms(dto 묶음)에 저장된 데이터를 엔티티 묶음으로 변환한다.
		/*
		List<Article> articleList = new ArrayList<>();
		
		for (int i = 0; i < articleForms.size(); i++ ) {
//			Article entity = articleForms.get(i).toEntity();
//			articleList.add(entity);
			articleList.add(articleForms.get(i).toEntity());
		}
		*/
//		ArticleForm 객체가 저장된 List를 stream 으로 변환한 후 Article 객체로 변환하여 List에 추가한다.
		List<Article> articleList = articleForms.stream()
									.map(entity -> entity.toEntity())
									.collect(Collectors.toList());
		
		System.out.println("ArticleService -> #articleList -> " + articleList);
		
//		엔티티 묶음을 Article 테이블에 저장한다.
//		for (Article entity : articleList) {
//			articleRepository.save(entity);
//		}
		
		articleList.stream()
				.forEach(article -> articleRepository.save(article));
		
//		강제 예외 발생
		articleRepository.findById(-1L).orElseThrow(
				() -> new IllegalArgumentException("저장 실패!!!")
				);
		
		return articleList;
	}
	 
	
	
	
	
}
