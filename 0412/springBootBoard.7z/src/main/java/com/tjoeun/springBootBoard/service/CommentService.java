package com.tjoeun.springBootBoard.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tjoeun.springBootBoard.dto.CommentDto;
import com.tjoeun.springBootBoard.entity.Comment;
import com.tjoeun.springBootBoard.repository.ArticleRepository;
import com.tjoeun.springBootBoard.repository.CommentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CommentService {
	
//	ArticleRepository와 CommentRepository 인터페이스의 JPA 메소드를 사용하기 위해
//	ArticleRepository와 CommentRepository 인터페이스의 bean을 가져온다.
	@Autowired
	private ArticleRepository articleRepository;
	@Autowired
	private CommentRepository commentRepository;
	
	
//	특정 메인글 id에 따른 댓글 목록 조회
	public List<Comment> comments(Long articleId) {
		log.info("CommentService -> comments()");
		List<Comment> comments = commentRepository.findByArticleId(articleId);
		
		
		return comments;
	}
	
	
	
	
	
}
