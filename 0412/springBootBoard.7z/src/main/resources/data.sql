INSERT INTO article(id, title, content) VALUES (1, '아이유', '너의 의미');
INSERT INTO article(id, title, content) VALUES (2, '2PM', '우리집');
INSERT INTO article(id, title, content) VALUES (3, '세븐틴', '손오공');
INSERT INTO article(id, title, content) VALUES (4, '부석순', '파이팅해야지');