-- article 테이블 dummy 데이터
INSERT INTO article(id, title, content) VALUES (1, '당신의 인생드라마는?', '댓글');
INSERT INTO article(id, title, content) VALUES (2, '너의 이름은?', '댓글');
INSERT INTO article(id, title, content) VALUES (3, '행복하십니까?', '댓글');
INSERT INTO article(id, title, content) VALUES (4, '너는 누구입니까?', '댓글');

--comment 테이블 dummy 데이터
--1번 게시물 댓글
INSERT INTO comment(id, article_id, nickname, body) VALUES (1, 1, '크리스', '눈물의여왕');
INSERT INTO comment(id, article_id, nickname, body) VALUES (2, 1, '앨런', '나의해방일지');
INSERT INTO comment(id, article_id, nickname, body) VALUES (3, 1, '프랭크', '오징어게임');


--2번 게시물 댓글
INSERT INTO comment(id, article_id, nickname, body) VALUES (4, 2, '크리스', '크리스');
INSERT INTO comment(id, article_id, nickname, body) VALUES (5, 2, '앨런', '앨런');
INSERT INTO comment(id, article_id, nickname, body) VALUES (6, 2, '프랭크', '프랭크');


--3번 게시물 댓글
INSERT INTO comment(id, article_id, nickname, body) VALUES (7, 3, '크리스', '아니');
INSERT INTO comment(id, article_id, nickname, body) VALUES (8, 3, '앨런', '행복합니다.');
INSERT INTO comment(id, article_id, nickname, body) VALUES (9, 3, '프랭크', '행복.. 그게 뭔데????');