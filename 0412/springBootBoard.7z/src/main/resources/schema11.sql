CREATE IF NOT EXISTS TABLE article (
	id INT auto_increment NOT NULL,
	title varchar(100) NOT NULL,
	content varchar(1000) NOT NULL,
	CONSTRAINT article_pk PRIMARY KEY (id)
);