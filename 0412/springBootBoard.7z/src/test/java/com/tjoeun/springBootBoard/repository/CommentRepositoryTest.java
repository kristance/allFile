package com.tjoeun.springBootBoard.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.tjoeun.springBootBoard.entity.Article;
import com.tjoeun.springBootBoard.entity.Comment;

//	@SpringBootTest 어노테이션은 full application config를 로드해서 통합 테스트르 실행한다.
//	@DataJpaTest 어노테이션은 JPA 컴포넌트들만을 대상으로 테스트를 실행한다.
//	@SpringBootTest 어노테이션을 붙여주면 springBoot와 연동한 통합 테스트를 수행할 수 있고,
//	@DataJpaTest 어노테이션을 붙여주면 JPA와 연동한 테스트를 수행할 수 있다. 
@DataJpaTest
class CommentRepositoryTest {

	@Autowired
	private CommentRepository commentRepository;
	
//	@DisplayName 어노테이션은 JUnit 실행 결과에 메소드 이름대신 출력할 테스트 제목을 지정한다.
	@Test
	@DisplayName("특정 메인글의 모든 댓글 조회")
	void testFindByArticleId() {
//		1번 메인글의 모든 댓글 조회 -> 댓글 있음
		{
		Long articleId = 1L;
//		예상
		Article article = new Article().builder().id(1L).title("당신의 인생드라마는?").content("댓글").build();
		Comment comment1 = new Comment().builder().id(1L).article(article).nickname("크리스").body("눈물의여왕").build();
		Comment comment2 = new Comment().builder().id(2L).article(article).nickname("앨런").body("나의해방일지").build();
		Comment comment3 = new Comment().builder().id(3L).article(article).nickname("프랭크").body("오징어게임").build();
		List<Comment> expected = Arrays.asList(comment1, comment2, comment3);
		System.out.println("CommentRepositoryTest -> findByArticleId() -> expected ->" + expected);

//		실제
		List<Comment> actual = commentRepository.findByArticleId(articleId);
		System.out.println("CommentRepositoryTest -> findByArticleId() -> actual ->" + actual);
		
//		비교
		assertEquals(expected.toString(), actual.toString(), "1번 메인글의 모든 댓글 조회");
		}
		
//		4번 메인글의 모든 댓글 조회 -> 댓글 없음
		{
		Long articleId = 4L;
		List<Comment> expected = Arrays.asList();
		List<Comment> actual = commentRepository.findByArticleId(articleId);
		assertEquals(expected.toString(), actual.toString(),  "4번 메인글의 모든 댓글 조회");
		}
	}
	
//		특정 닉네임의 모든 댓글 조회
	@Test
	@DisplayName("특정 닉네임의 모든 댓글 조회")
	void testFindByNickname() {
//		크리스 닉네임의 모든 댓글 조회 -> 댓글 있음
		{
		String nickname = "크리스";
//		예상
		Article article1 = new Article().builder().id(1L).title("당신의 인생드라마는?").content("댓글").build();
		Article article2 = new Article().builder().id(2L).title("너의 이름은?").content("댓글").build();
		Article article3 = new Article().builder().id(3L).title("행복하십니까?").content("댓글").build();
		Comment comment1 = new Comment().builder().id(1L).article(article1).nickname(nickname).body("눈물의여왕").build();
		Comment comment2 = new Comment().builder().id(4L).article(article2).nickname(nickname).body("크리스").build();
		Comment comment3 = new Comment().builder().id(7L).article(article3).nickname(nickname).body("아니").build();
		List<Comment> expected = Arrays.asList(comment1, comment2, comment3);
		System.out.println("CommentRepositoryTest -> findByArticleId() -> expected ->" + expected);

//		실제
		List<Comment> actual = commentRepository.findByNickname(nickname);
		System.out.println("CommentRepositoryTest -> findByArticleId() -> actual ->" + actual);

//		비교
		assertEquals(expected.toString(), actual.toString(), "닉네임이 크리스인 모든 댓글 조회");
		}
		
//		칼스 닉네임의 모든 댓글 조회 -> 댓글 없음
		{
			String nickname = "칼스";
//		예상
			List<Comment> expected = Arrays.asList();
			System.out.println("CommentRepositoryTest -> findByArticleId() -> expected ->" + expected);
			
//		실제
			List<Comment> actual = commentRepository.findByNickname(nickname);
			System.out.println("CommentRepositoryTest -> findByArticleId() -> actual ->" + actual);
			
//		비교
			assertEquals(expected.toString(), actual.toString(), "닉네임이 칼스인 모든 댓글 조회");
		}
		
		
	}

}
