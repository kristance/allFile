package com.tjoeun.springBootBoard.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.tjoeun.springBootBoard.dto.ArticleForm;
import com.tjoeun.springBootBoard.entity.Article;

//	@SpringBootTest 어노테이션을 붙여서 springBoot와 연동한 통합 테스트를 수행한다.
@SpringBootTest
class ArticleServiceTest {
	
	@Autowired
	private ArticleService articleService;
	
//	Article 테이블 전체 목록 조회 테스트
	@Test
	void testIndex() {
//		Index() 메소드가 실행되었을 때 예상되는 결과를 만든다.
		Article article1 = new Article().builder().id(1L).title("아이유").content("너의 의미").build();
		Article article2 = new Article().builder().id(2L).title("2PM").content("우리집").build();
		Article article3 = new Article().builder().id(3L).title("세븐틴").content("손오공").build();
		Article article4 = new Article().builder().id(4L).title("부석순").content("파이팅해야지").build();
		/*
		 Article article1 = new Article(1L, "아이유", "너의 의미");
		 Article article2 = new Article(2L, "2PM", "우리집");
		 Article article3 = new Article(3L, "세븐틴", "손오공");
		 Article article4 = new Article(4L, "부석순", "파이팅해야지");
		 */
		List<Article> expected = new ArrayList<Article>(Arrays.asList(article1, article2, article3, article4));
		System.out.println("## JUnit -> testIndex() -> expected -> " + expected);
		
//		index() 메소드가 실제로 실행되었을 때 결과를 얻어온다.
		List<Article> actual =  articleService.index();
		System.out.println("## JUnit -> testIndex() -> actual -> " + actual);
		
//		예상되는 결과와 실제로 실행되었을 때의 결과를 비교한다.
		assertEquals(expected.toString(), actual.toString());
		
	}

	
//	Article 테이블 단일 목록 조회 테스트 -> 성공
	@Test
	void testShow_id가_존재하는_경우_성공() {
//		예상
		Article expected = new Article().builder().id(1L).title("아이유").content("너의 의미").build();
		System.out.println("## JUnit -> testShow()success -> expected -> " + expected);
//		실제
		Article actual = articleService.show(1L);
		System.out.println("## JUnit -> testShow()success -> actual -> " + actual);
//		비교
		assertEquals(expected.toString(), actual.toString());
		
	}
//	Article 테이블 단일 목록 조회 테스트 -> 실패
	@Test
	void testShow_id가_존재하지_않는_경우_실패() {
//		예상
		Article expected = null;
		System.out.println("## JUnit -> testShow()failure -> expected -> " + expected);
//		실제
		Article actual = articleService.show(-1L);
		System.out.println("## JUnit -> testShow()failure -> actual -> " + actual);
//		비교
		assertEquals(expected, actual);
		
	}

	
//	Article 테이블 글 저장 테스트 -> 성공
	@Test
//	테스트 메소드에 @Transactional 어노테이션을 붙여주면 테스트 종료 후 변경된 데이터를 rollback 처리한다.
	@Transactional
	void testCreate_저장성공_id_포함X_() {
//		예상
		String title = "목성";
		String content = "위성_가니메데";
		Article expected = new Article().builder().id(5L).title(title).content(content).build();
		System.out.println("## JUnit -> testCreate_저장성공_id_포함X_ -> expected -> " + expected);
//		실제
		Article actual = articleService.create(new ArticleForm().builder().id(null).title(title).content(content).build());
		System.out.println("## JUnit -> testCreate_저장성공_id_포함X_ -> actual -> " + actual);
//		비교
		assertEquals(expected.toString(), actual.toString());
		
	}
	
//	Article 테이블 글 저장 테스트 -> 실패
	@Test
	@Transactional
	void testCreate_저장실패_id_포함O_() {
//		예상
		String title = "목성";
		String content = "위성_가니메데";
		Article expected = null;
		System.out.println("## JUnit -> testCreate_저장실패_id_포함O_ -> expected -> " + expected);
//		실제
		Article actual = articleService.create(new ArticleForm().builder().id(5L).title(title).content(content).build());
		System.out.println("## JUnit -> testCreate_저장실패_id_포함O_ -> actual -> " + actual);
//		비교
		assertEquals(expected, actual);
	
	}

//	Article 테이블 글 수정 테스트 -> 성공
	@Test
	@Transactional
	void testUpdate_성공_id존재_title_content_둘_다_존재() {
//		예상
		Long id = 2L;
		String title = "오타니";
		String content = "LA다저스";
		Article expected = new Article().builder().id(id).title(title).content(content).build();
		System.out.println("## JUnit -> testUpdate_성공_id존재_title_content_둘_다_존재 -> expected -> " + expected);
		
//		실제
		Article actual = articleService.update(id, new ArticleForm().builder().id(id).title(title).content(content).build());
		System.out.println("## JUnit -> testUpdate_성공_id존재_title_content_둘_다_존재 -> actual " + actual);
		
//		비교
		assertEquals(expected.toString(), actual.toString());
		
	}

	@Test
	@Transactional
	void testUpdate_성공_id존재_title_존재() {
//		예상
		Long id = 2L;
		String title = "오타니";
		String content = null;
		Article expected = new Article().builder().id(id).title(title).content("우리집").build();
		System.out.println("## JUnit -> testUpdate_성공_id존재_title_존재 -> expected -> " + expected);
//		실제
		Article actual = articleService.update(id, new ArticleForm().builder().id(id).title(title).content(content).build());
		System.out.println("## JUnit -> testUpdate_성공_id존재_title_존재 -> actual -> " + expected);
//		비교
		assertEquals(expected.toString(), actual.toString());
	}
	
	@Test
	@Transactional
	void testUpdate_성공_id존재_content_존재() {
//		예상
		Long id = 2L;
		String title = null;
		String content = "LA다저스";
		Article expected = new Article().builder().id(id).title("2PM").content(content).build();
		System.out.println("## JUnit -> testUpdate_성공_id존재_title_존재 -> expected -> " + expected);
//		실제
		Article actual = articleService.update(id, new ArticleForm().builder().id(id).title(title).content(content).build());
		System.out.println("## JUnit -> testUpdate_성공_id존재_title_존재 -> actual -> " + expected);
//		비교
		assertEquals(expected.toString(), actual.toString());
		
	}
	
//	Article 테이블 글 수정 테스트 -> 실패
	@Test
	@Transactional
	void testUpdate_실패_id존재X() {
//		예상
		Long id = 6L;
		String title = "오타니";
		String content = "LA다저스";
		Article expected = null;
		System.out.println("## JUnit -> testUpdate_실패_id존재X -> expected -> " + expected);
		
//		실제
		Article actual = articleService.update(id, new ArticleForm().builder().id(id).title(title).content(content).build());
		System.out.println("## JUnit -> testUpdate_실패_id존재_title_존재 -> actual -> " + expected);
		
//		비교
		assertEquals(expected, actual);
	}
	
	@Test
	@Transactional
	void testUpdate_실패_id존재_title_content_존재X() {
//		예상
		Long id = 3L;
		String title = null;
		String content = null;
		Article expected = null;
		System.out.println("## JUnit -> testUpdate_실패_id존재X -> expected -> " + expected);
		
//		실제
		Article actual = articleService.update(id, new ArticleForm().builder().id(id).title(title).content(content).build());
		System.out.println("## JUnit -> testUpdate_실패_id존재_title_존재 -> actual -> " + expected);
		
//		비교
		assertEquals(expected, actual);
	}
		
	
	
//	Article 테이블 글 삭제 테스트 -> 성공
	@Test
	@Transactional
	void testDelete_성공_ID_O() {
//		예상
		Long id = 3L;
		Article expected = new Article().builder().id(id).title("세븐틴").content("손오공").build();
//		실제
		Article actual = articleService.delete(id); 
//		비교
		assertEquals(expected.toString(), actual.toString());
		
	}
	
//	Article 테이블 글 삭제 테스트 -> 실패
	@Test
	@Transactional
	void testDelete_실패_ID_X() {
//		예상
		Long id = -1L;
		Article expected = null;
//		실제
		Article actual = articleService.delete(id);
//		비교
		assertEquals(expected, actual);
		
	}

}
